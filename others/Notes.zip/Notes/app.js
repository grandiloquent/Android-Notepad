;
(function () {

    var container = document.getElementById('container');


    if (!container || typeof domtoimage === undefined) {
        console.log('Lack of necessary master');
        return;
    }

    domtoimage.toJpeg(container)
        .then(function (dataUrl) {
            var img = new Image();
            img.src = dataUrl;
            document.body.appendChild(img);
        })
        .catch(function (error) {
            console.error('oops, something went wrong!', error);
        });

})()