"# Kotlin-Notes" 

<img src="screenshot/Screenshot_1.jpg" height="30%" width="30%">